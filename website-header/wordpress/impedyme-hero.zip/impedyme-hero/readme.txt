=== Impedyme Hero Slider ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Responsive two-slide homepage header for impedyme.com.

== Usage ==
Add the shortcode [impedyme_hero] to a full-width section (for example a BeBuilder
Column item in place of the old Slider Revolution shortcodes, an Elementor
"Shortcode" widget, or a Gutenberg "Shortcode" block).

The videos and images are bundled in the plugin's media/ folder.
Text, links and timing live in templates/impedyme-hero.html and assets/.
